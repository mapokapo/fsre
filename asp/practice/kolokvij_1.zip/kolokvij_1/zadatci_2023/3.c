#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int funkcija(int n, int k)
{
	if (k < 1)
		return 1;
	if (k == 1)
		return n;

	return n * funkcija(n, k - 1);
}

int main()
{
	int a, b;

	printf("Unesite a i b: ");
	scanf("%d %d", &a, &b);

	printf("%d^%d=%d\n", a, b, funkcija(a, b));

	return 0;
}